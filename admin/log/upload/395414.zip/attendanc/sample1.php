<?php
global $USER,$DB;
$uid=$USER->id;
$firstname= $USER->firstname;
$lastname= $USER->lastname;
$username=$firstname. ' ' .$lastname;
$sql="select c.id,c.fullname
				from mdl_course AS c
				JOIN mdl_context ct ON c.id = ct.instanceid
JOIN mdl_role_assignments ra ON ra.contextid = ct.id
JOIN mdl_user u ON u.id = ra.userid
where u.id=".$uid;
$exe=$DB->get_records_sql($sql,null, $limitfrom=0, $limitnum=0);
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Attendance Form </title>
    <meta name="developer" content="dr:Alshimaa Abdelraof">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
<div class="container">
   
    <form name="attendance" action="add_attendance.php" method="post"  style="text-align: right" enctype="multipart/form-data">
        <!-- start name-->

            <div class="form-group">

             الاسم   <input type="text" class="form-control" id="inputName" name="name" value="<?php echo $username; ?>" required readonly>
            </div>
            
            <select id="coursename" name="coursename" class="custom-select  mb-3" required>

                    <option value="#" selected> اختار الكورس  </option>
                    <?php 
                  

foreach ($exe as $record) {        
            echo "<option value='". $record->id ."'>" .$record->fullname."</option>";  // displaying data in option menu
        }	
    ?> 
                            
                  
                    ?>
                </select>
        <!-- end name -->
        
        <!-- end course name -->
        
        
            <div class="form-group">
                <label for="start-date">تاريخ المحاضرة</label>
                  <input type="date" class="form-control" id="start-date" name="coursedate" required/>
            </div>



        <!-- start college-->
        
        
            <div class="form-group">
                <label for="start-date">وقت بداية المحاضرة</label>
               
                  <input  type="time"  value="00:00" class="form-control" id="start-time" name="starttime"  required/>
            </div>

 <div class="form-group">
                <label for="start-date">وقت انتهاء المحاضرة</label>

                  <input  type="time"  value="00:00" class="form-control" id="end-time" name="endtime" required/>
            </div>



        <!-- start college-->

           <div class="form-group">
            <label for="inputCollege">الكلية</label>
            <select id="inputCollege" name="college" class="form-control" required>
                <option selected value="كليه الهندسه جامعه الازهر(بنين)">  كليه الهندسه جامعه الازهر(بنين)  </option>
                <option  value="كليه الهندسه جامعه الازهر(بنات)"> كليه الهندسه جامعه الازهر(بنات)  </option>
               
                <option  value="اخري">اخري </option>
            </select>
        </div>
         <!-- start القسم-->
           <div class="form-group">
               <label for="inputspecialization">القسم</label>
               <select id="inputGroup" name="specialization" class="form-control" required>
                   <option selected>اختر القسم</option>
                   <option value="هندسه النظم والحاسبات">هندسه النظم والحاسبات </option>
                   <option value="هندسه الميكانيكا">هندسه الميكانيكا</option>
                   <option value="هندسه الكهرباء"> هندسه الكهرباء </option>
                   <option  value="هندسه العمارة">هندسه العمارة </option>
                                      <option  value="هندسه التخطيط العمرانى">هندسه التخطيط العمرانى </option>
                                       <option  value="هندسه التعدين و البترول">هندسه التعدين و البترول </option>
                                 <option  value="الهندسة المدنية">الهندسة المدنية </option>
                                                        <option  value="الفرقة الاعدادية">الفرقة الاعدادية </option>




               </select>

           </div>
        <!--end التخصص-->

        <div class="form-group">
            <label for="inputGroup">الفرقة الدراسية</label>
            <select id="inputGroup" name="group" class="form-control" required>
                <option selected>اختر الفرقة الدراسية</option>
                <option value="الفرقه الاعداديه">الفرقه الاعداديه</option>
                <option value="الفرقه الاولي">الفرقه الاولي</option>
                <option value="الفرقه الثانيه"> الفرقه الثانيه</option>
                <option value="الفرقه الثالثه">الفرقه الثالثه</option>
                <option value="الفرقه الرابعه">الفرقه الرابعه</option>
                <option  value="اخري">اخري </option>
            </select>
        </div>

        <!--end college -->
               <!-- start course name-->

            <div class="form-group">

             عدد الحضور   <input type="text" class="form-control" id="no" name="no"  required >
            </div>
        <!-- end course name -->
        <!-- start course name-->

            <div class="form-group">

          ( only xls , xlsx , txt )   ملف الحضور   <input type="file" class="form-control" id="shimaa" name="shimaa"   >
            </div>
        <!-- end course name -->
           <div style="text-align: center">
          <button class="btn btn-primary" type="submit">submit</button>
      </div>
    </form>

</div>

<!-- bootstrap files cdn -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script>

</script>
</body>
</html>