<?php
require_once('../../config.php');
require_once('get_auth_token.php');

global $DB,$USER;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
// define variables and set to empty values
    $name = $coursename = $coursedate = $starttime = $endtime = $college= $group = $specialization = $no = $file=$textFile=$tmp_dir=$txtSize=$upload_dir= $txtExt=$usertext="";
    $userid = $USER->id;
    $name = test_input($_POST["name"]);
    $coursename = test_input($_POST["coursename"]);
	$group=test_input($_POST["group"]);
    $coursedate = test_input($_POST["coursedate"]);
    $starttime = test_input($_POST["starttime"]);
    $endtime = test_input($_POST["endtime"]);
    $college = test_input($_POST["college"]);
   $specialization = test_input($_POST["specialization"]);
   $no = test_input($_POST["no"]);
   $filename = $_FILES['shimaa']['name'];
     $txtSize = $_FILES['shimaa']['size'];

   $tmp_dir = $_FILES['shimaa']['tmp_name'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);
      $valid_extensions = array('txt','xls', 'xlsx', 'docx'); // valid extensions

   $txtname= rand(1000,1000000).".".$ext;
   $destination = 'uploads/' . $txtname;
  if(in_array($ext, $valid_extensions)){ 
    if($txtSize < 50000)    {
move_uploaded_file($tmp_dir, $destination);
    }
    else{
     $errMSG = "error in file.";
    }}
	  
  $sql="INSERT INTO`mdl_attendance`( `user_id`,`name`, `coursename`, `coursedate`, `starttime`, `endtime`,`college`, `specialization`,`group`, `no`,`usertext`)
         VALUES ("."'" .$userid."'" . "," .
        "'" .$name."'" ."," .
        "'" .$coursename."'" ."," .
        "'" .$coursedate ."'" .",".
        "'" .$starttime ."'" .",".
        "'" .$endtime ."'" .",".
        "'" .$college ."'" .",".
        "'" .$specialization ."'" .",".
        "'" .$group ."'" .",".
        "'" .$no ."'" ."
		,".
        "'" .$destination."'" ." )";
    $DB->execute($sql);
 header("Location: done.php");
            die();
//	//}
   
 

}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;

}
?>