<?php
/*
return user  token to auth with api's .
@return string token.
@param $DB ,$ $user_id
*/
function get_auth_token($DB , $user_id ,$tenant_id){
   $idps_info = get_idp_from_db($DB ,$user_id);
   return   array("Authorization: " .  $idps_info->token, "IdToken:" . $idps_info->idtoken,"TENANT_ID: " .$tenant_id);
}
function get_idp_from_db($DB ,$user_id){
   $idps_info = $DB->get_record('auth_oidc_token',array('userid'=>$user_id) , $fields='*', $strictness=IGNORE_MISSING);
return $idps_info;
}


