<?php
$string['pluginname'] = 'Attendanc Form';//اسم اللوك
$string['newBulk'] = 'Attendance block';//اللى بيظهر عند صفحة اللوك
$string['addAttendanc'] = 'Attendance Form';//العنوان
$string['bulkAttendanc'] = 'Add New Course Attendance';

$string['attendanc:addinstance'] = 'EduEdge attendace System';
$string['attendanc:myaddinstance'] = 'EduEdges attendance System ';


