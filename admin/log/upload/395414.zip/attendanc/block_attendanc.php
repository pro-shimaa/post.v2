<?php

class block_attendanc extends block_base {

    public function init() {
        $this->title = get_string('newBulk', 'block_attendanc');
    }


    // The PHP tag and the curly bracket for the class definition
    // will only be closed after there is another function added in the next section.
    public function get_content() {
    if ($this->content !== null) {
      return $this->content;
    }
    $url = new moodle_url('/blocks/attendanc/view.php');

    $this->content         =  new stdClass;
    $this->content->text   =html_writer::link($url, get_string('addAttendanc', 'block_attendanc'));


    return $this->content;
}


public function instance_allow_multiple() {
  return false;
}
}
