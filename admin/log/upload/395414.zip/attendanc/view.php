<?php
require_once('../../config.php');

global $DB, $OUTPUT, $PAGE,$CFG;

// Next look for optional variables.
    $context = context_system::instance();
    $PAGE->set_context($context);

$editurl = new moodle_url('/blocks/attendanc/view.php');

//set page url .
 $PAGE->set_url('/blocks/attendanc/view.php');
 $PAGE->set_pagelayout('standard');
 $PAGE->set_heading(get_string('newBulk', 'block_attendanc'));



    echo $OUTPUT->header();
     require_once('sample1.php');
    echo $OUTPUT->footer();
